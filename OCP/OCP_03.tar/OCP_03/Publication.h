#pragma once

#include "Avion.h"

class Publication
{
public:
	Publication();
	Publication(Avion &cetAvion);
	virtual ~Publication();


protected:

private:
	

};


