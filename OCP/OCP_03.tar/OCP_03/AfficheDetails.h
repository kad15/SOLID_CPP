#pragma once
#include "Avion.h"

class AfficheDetails
{
public:
	AfficheDetails(Avion &cetAvion);
	virtual ~AfficheDetails();
};

